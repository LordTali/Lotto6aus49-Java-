package Lotto;
import java.util.Arrays;

// Diese Datei steuert den Programmablauf.


public class Programm {



    public static void main(String[] args) {
        boolean nochmal = false;
        Pause.warten();
        System.out.println("Herzlich willkommen beim Lottospielen!\n");
        Pause.wartenLang();
        do {
            Benutzer.raten();
            Pause.warten();
            Benutzer.superzahlTippen();
            Pause.warten();
            Benutzer.ausgeben();
            Pause.warten();
            Glueckszahlen.ziehen();
            Pause.warten();
            Glueckszahlen.superzahlZiehen();
            Pause.warten();
            Gewinn.auswerten();
            Pause.warten();
            if (Gewinn.nummer_richtige >= 3)
            {
                Gewinn.gewinn_ermitteln();
                Pause.warten();
            }
            else
            {
                Pause.wartenLang();
                System.out.println("Viel Glück beim nächsten Mal!");
            }
            Pause.warten();
            Gewinn.loeschen();
            Benutzer.loeschen();
            nochmal = Wiederholung.wiederholen();
            Pause.warten();
        }
        while (nochmal);

        System.out.println("Auf Wiedersehen und danke fürs Spielen!");

    }
}