package Lotto;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.Arrays;

// Diese Datei steuert die Eingabe der vom Benutzer getippten Zahlen.

class Benutzer implements Suche {
    static int[] ratezahlen = new int[6];
    static int zahl;
    static int superzahl;
    static boolean superzahlpruefung;


    static void raten() {


        for (int nummer = 0; nummer < 6; ) // Eingabeschleife
        {
            int durchlauf = 0;
            try {
                Scanner eingabe = new Scanner(System.in);
                System.out.print("Bitte geben Sie eine Zahl zwischen 1 und 49 ein. \n > ");
                Pause.warten();
                zahl = eingabe.nextInt();
                boolean pruefung = Suche.arrayPruefen(ratezahlen, zahl, ++durchlauf); // Ausschluss der Zahlwiederholung
                if (pruefung)
                {
                    System.out.println("Sie haben diese Auswahl bereits getroffen.");
                    Pause.wartenKurz();
                    System.out.println("Bitte wählen Sie eine andere Zahl.\n");
                    Pause.warten();
                } else if (zahl < 1 || zahl > 49) {
                    System.out.println("Die Zahl muss zwischen 1 und 49 liegen. Bitte versuchen Sie es erneut.");
                    Pause.warten();
                } else {
                    ratezahlen[nummer] = zahl;
                    System.out.println("Eingegebene Zahlen: " + (nummer + 1) + "/" + ratezahlen.length + ".\n");
                    ++nummer;
                    Pause.warten();

                }
            } catch (InputMismatchException eingabefehler) // Auffangen einer ungültigen Eingabe
            {
                System.out.println("Ungültige Eingabe. Bitte geben Sie eine Zahl ein.\n");
                Pause.warten();
            }
        }
    }

        static void superzahlTippen()
        {
            do
            {
                try
                {
                    System.out.print("Geben Sie jetzt Ihre Superzahl ein.\n > ");

                    Scanner eingabe = new Scanner(System.in);
                    superzahl = eingabe.nextInt();

                    if (superzahl < 0 || superzahl > 9)
                    {
                            System.out.println("Die Superzahl muss zwischen 0 und 9 liegen. " +
                                    "Bitte versuchen Sie es erneut.\n");
                            Pause.warten();
                    }
                    else superzahlpruefung = true;
                    }
                catch (InputMismatchException eingabefehler)
                {
                    System.out.println("Ungültige Eingabe. Bitte geben Sie eine Zahl ein.\n");
                    Pause.warten();
                }
            }
            while (superzahlpruefung == false);

                Pause.warten();
                System.out.println("Ihre Superzahl ist also " + superzahl + ".");
                Pause.warten();

        }

        static void ausgeben()  // Ausgabe der getippten Zahlen
        {

            System.out.println("Ihre getippten Zahlen sind: ");
            for (int zaehler = 0; zaehler < ratezahlen.length; ++zaehler)
            {
                System.out.print(ratezahlen[zaehler] + "   ");
            }
        System.out.print("\n");
        Pause.warten();
        }

        static void loeschen()      // Zurücksetzen der Zahlen für spätere Spiele
        {
            ratezahlen = new int[6];
            superzahlpruefung = false;
        }
    }
