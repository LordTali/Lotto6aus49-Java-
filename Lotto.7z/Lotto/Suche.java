package Lotto;

/* Diese Datei ist ein Interface, auf das sowohl der Benutzer als auch die Gewinnzahlen zugreifen.
Die Methode arrayPruefen überprüft, ob eine Zahl mehr als einmal benutzt wurde.

 */

interface Suche
{
    static boolean arrayPruefen(int[] glueckszahlen, int zahl, int durchlauf)
    {
        for (int element = 0; element < durchlauf; element++)
        {
            if(glueckszahlen[element] == zahl)
            {
                return true;
            }

        }
        return false;
    }

}
