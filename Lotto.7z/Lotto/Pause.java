package Lotto;

// Diese Datei steuert Anzeigepausen, für ein angenehmeres Spielerlebnis.

public class Pause {

    static void warten()
    {
        try
        {
            Thread.sleep(800);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    static void wartenKurz()
        {
            try
            {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    static void wartenLang()
    {
        try
        {
            Thread.sleep(1200);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
}
