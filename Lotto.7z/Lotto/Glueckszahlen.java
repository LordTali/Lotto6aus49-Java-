package Lotto;
import java.util.Arrays;
import java.util.Random;

// Mit dieser Datei werden die Gewinnzahlen gezogen.

public class Glueckszahlen implements Suche {

    static int[] glueckszahl;
    static int[] zahlen = new int[6];
    static int superzahl;



    static void ziehen()
    {
        System.out.println("Und hier kommen die neusten Gewinnzahlen:");
        for (int durchlauf = 0; durchlauf < 6; durchlauf++)
        {
            int glueckszahl = new Random().nextInt(1, 50);
            boolean pruefung = Suche.arrayPruefen(zahlen, glueckszahl, durchlauf); // Prüfung der Zahlwiederholung

            while (Suche.arrayPruefen(zahlen, glueckszahl, durchlauf)) // Ausschluss der Zahlwiederholung
            {
                glueckszahl = new Random().nextInt(1, 50);
            }


            zahlen[durchlauf] = glueckszahl;    // Übertragung ins Gewinnzahlen-Array
        }
        Arrays.sort(zahlen);
        for (int durchlauf = 0; durchlauf < zahlen.length; durchlauf++) // Ausgabe der Gewinnzahlen
        {
            System.out.print(zahlen[durchlauf] + "   ");
            Pause.wartenLang();
        }

        System.out.println("\n");
        Pause.warten();
    }

    static void superzahlZiehen()       // Ziehung der Superzahl
    {
        superzahl =  new Random().nextInt(0, 10);
        System.out.println("Die Superzahl ist " + superzahl + ".\n");
        Pause.wartenLang();
    }

}
