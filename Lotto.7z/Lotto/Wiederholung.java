package Lotto;
import java.util.Scanner;
 class Wiederholung

 // In dieser Datei werden die Benutzer gefragt, ob sie noch einmal spielen oder das Programm beenden wollen.
{
    static boolean wiederholen()
    {
        System.out.print("\nWollen Sie noch einmal spielen? (J/N)\n > ");
        Pause.warten();
    Scanner eingabe = new Scanner(System.in);
    String antwort = eingabe.nextLine();
    if (antwort.toLowerCase().contains("j")) {
        return true;
    }
    else {return false;}
    }
}
