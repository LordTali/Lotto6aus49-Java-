package Lotto;
import java.util.Random;

// In dieser Datei wird die Übereinstimmung der getippten und Gewinnzahlen bestimmt und ggf der Gewinn ausgeschüttet.

class Gewinn {
    static int nummer_richtige = 0;
    static boolean zusatz;
    static boolean jackpot;

    static void auswerten()
    {
        if (Benutzer.superzahl == Glueckszahlen.superzahl)
        {
            zusatz = true;
        }
        else
        {
            zusatz = false;
        }

        for (int durchlauf = 0; durchlauf < Benutzer.ratezahlen.length; durchlauf++) // Prüfung der Übereinstimmunv
        {
            for (int iteration = 0; iteration < Glueckszahlen.zahlen.length; iteration++) {
                if (Benutzer.ratezahlen[iteration] == Glueckszahlen.zahlen[durchlauf]) {
                    nummer_richtige++;
                }

            }
        }
        if (nummer_richtige == 1) {
            System.out.println("Sie haben " + nummer_richtige + " richtige Zahl getippt.");
        } else {
            System.out.println("Sie haben " + nummer_richtige + " richtige Zahlen getippt.");
        }
        Pause.wartenLang();
        if (nummer_richtige >= 3) {
            System.out.println("Herzlichen Glückwunsch! Sie haben etwas gewonnen! :)");
        } else {
            System.out.println("Schaaaaade. Nichts gewonnen. :(\n");
        }
        Pause.warten();
    }


    static void loeschen() // Zurücksetzen der Zahlen für spätere Spiele
    {
        nummer_richtige = 0;
        jackpot = false;
    }

    static void gewinn_ermitteln()
    {
        int minimum = 0;
        int maximum = 0;
        double gewinn;
        switch(nummer_richtige)
        {
            case 2:
                if (zusatz)
                    {
                    minimum = 5;
                    maximum = 7;
                    break;
                    }
                else
                    {
                        Gewinn.nummer_richtige = 2;
                        return;
                    }
            case 3:
                if (zusatz)
                {
                    minimum = 5;
                    maximum = 7;
                    break;
                }
                else
                {
                    minimum = 10;
                    maximum = 31;
                    break;
                }

            case 4:
                if (zusatz)
                {
                    minimum = 100;
                    maximum = 501;
                    break;
                }
                else {
                    minimum = 30;
                    maximum = 101;
                    break;
                }
            case 5:
                if (zusatz)
                {
                    minimum = 10_000;
                    maximum = 50_001;
                    break;
                }
                else
                {
                    minimum = 2000;
                    maximum = 5001;
                    break;
                }
            case 6:
                if (zusatz)
                {
                    minimum = 1_000_000;
                    maximum = 30_000_000;
                    jackpot = true;
                    break;
                }
                else
                {
                    minimum = 100_000;
                    maximum = 1_000_001;
                    break;
                }
        }
        gewinn = new Random().nextInt(minimum, maximum);
        if (jackpot)
        {
            System.out.println("Wow! SIE HABEN DEN JACKPOT GEKNACKT!!!");
            Pause.wartenLang();

        }
        System.out.println("Ihr Gewinn beträgt " + gewinn + "€.");
        Pause.warten();
        System.out.println("Herzlichen Glückwunsch!");
        Pause.warten();
    }
}
